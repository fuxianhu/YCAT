s='television'
print(s[4:-2])