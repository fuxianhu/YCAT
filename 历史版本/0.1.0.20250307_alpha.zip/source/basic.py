from typing import *
from tkinter import *
from tkinter.ttk import *
from tkinter.filedialog import *
from tkinter.messagebox import *
from pathlib import Path
from urllib.parse import urlparse, unquote
from queue import Queue
from log import *
import json
import os
import requests
import threading
import getpass
import configparser
import sys
import multiprocessing
import toml
import ctypes


def restart_program():
    """
    重启程序
    """
    os.execv(sys.executable, ['python'] + sys.argv)


folder = "E:/YFY/YCAT"
json_data = None




def OpenJSON(file_path= f'{folder}/data/CatData.json'):
    """
    解析JSON文件
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)


json_data = OpenJSON()
data = OpenJSON(f"{folder}/data/data.json")


def SaveJSON(json_data, file_path= f'{folder}/data/CatData.json'):
    """
    保存JSON文件
    """
    with open(file_path, 'w', encoding='utf-8') as f:
        json.dump(json_data, f)


if type(json_data) != dict:
    raise TypeError("YFYCAT: data.json is not a dict.")


# 读取语言文件
lang = configparser.ConfigParser()
lang.read(f"./language/{json_data['language']}.conf", encoding="utf-8")
lang = dict([(key, str(value)) for key, value in lang.items ('language')])



VERSION = "0.1.0.20250307_alpha"
title = f"{lang['title']} {VERSION}"

