# YFY's comprehensive auxiliary tool
# YCAT

from Home import Home
from basic import *

if __name__ != '__main__':
    os._exit(0)



os.system("CLS") # 清屏




root = Tk()
root.iconbitmap(f"{folder}/icon/tool.ico")
root.geometry(f"{str(json_data['window_x'])}x{str(json_data['window_y'])}")

# 设置窗口透明度
root.attributes("-alpha", json_data['window_alpha'])  # 设置窗口透明度，0.0为完全透明，1.0为不透明

home = Home(root)



root.mainloop()

